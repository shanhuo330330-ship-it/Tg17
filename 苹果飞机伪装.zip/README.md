# ProxyProfileDemo / TDLib Telegram Client

这是一个 SwiftUI iOS 示例工程，现包含一个基于官方 TDLib 的独立 Telegram 客户端接入层。

## 当前功能

- 独立的 Telegram 登录页面，不打开、不注入官方 Telegram App。
- TDLib 登录状态机：手机号、验证码、两步验证密码、登录完成。
- 使用 TDLib 的 `getChats` 加载最近会话标题和未读数（只读预览）。
- 使用 TDLib `addProxy` 配置本独立客户端的 HTTP 或 SOCKS5 代理。
- TDLib 数据库目录位于 App 的 Application Support，数据库加密密钥保存在 iOS Keychain。
- 代理页仍提供出口 IP 测试；代理只对本 App 的 TDLib 客户端和测试请求生效。
- 设备资料页生成合成资料，并默认注入本 App 的 TDLib 客户端：Telegram 侧看到的 device_model / system_version / language_code 即该资料。资料变化或开关切换时，客户端会以新身份重新初始化。

## 明确边界

- 不修改系统真实 UDID、IMEI、序列号或 MAC（iOS 也从不向 App 暴露这些标识，Telegram 本身看不到）。App 控制的是自己上报给 Telegram 的参数（device_model / system_version / 语言）和自己 TDLib 流量的出口 IP。
- 不向官方 Telegram App 注入参数，不接管官方 Telegram 的登录流程。
- 不影响其他 App，也不是全设备 VPN。
- 注入开关关闭时，TDLib 使用真实设备参数初始化；开启时使用合成资料。两种模式都只影响本 App 进程，不影响系统和其他 App。
- 请只使用你有权使用的 Telegram 账号和代理。

## 启用真实 TDLib

默认工程未附带 TDLib 的 iOS 预编译二进制，因此默认会显示“等待配置 TDLib”。在 macOS/Xcode 上启用实际 Telegram 登录需要：

1. 从 Telegram 官方开发者页面创建自己的 API ID/API Hash。
2. 在本地 `ProxyProfileDemo/TelegramSecrets.swift` 中填写：

   ```swift
   static let apiID: Int32 = 123456
   static let apiHash = "你的 api_hash"
   ```

3. 从官方 `tdlib/td` 源码构建适用于 iOS 目标架构的 `TDLib.xcframework`，并将其加入 App target。
4. 确认 Bridging Header 设置为：

   ```text
   ProxyProfileDemo/TDLibBridge.h
   ```

5. 在 App target 的 **Build Settings → Active Compilation Conditions** 增加：

   ```text
   TD_LIB_ENABLED
   ```

6. 在真机或模拟器运行。

详细的 C 桥接函数、登录状态和代理接入说明见 `TDLibIntegration.md`。

## 当前未实现

这是独立客户端的登录与会话列表基础，不是完整 Telegram 替代客户端。当前还未实现：

- 消息详情和消息发送
- 图片、文件、语音和视频
- 联系人、群组管理
- 推送通知
- MTProto 代理 UI
- 全设备代理

## 目录

- `ProxyProfileDemo/TelegramClient.swift`：TDLib JSON 客户端、登录状态机、会话列表和代理配置
- `ProxyProfileDemo/TelegramView.swift`：独立 Telegram 登录与只读会话界面
- `ProxyProfileDemo/TDLibBridge.h`：TDLib C API 桥接声明
- `ProxyProfileDemo/TelegramSecrets.swift`：本地 API ID/API Hash 占位配置
- `ProxyProfileDemo/KeychainStore.swift`：TDLib 数据库密钥的 Keychain 存储
- `TDLibIntegration.md`：TDLib 二进制和 Xcode 接入步骤

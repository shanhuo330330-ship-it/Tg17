# TDLib 接入说明

当前工程默认以“未接入 TDLib”模式编译，因此没有第三方二进制时也能打开界面。要启用真实 Telegram 客户端，需要在 macOS/Xcode 中完成以下步骤。

## 1. 获取 Telegram API ID/API Hash

在 Telegram 官方开发者页面创建自己的应用，得到 `api_id` 和 `api_hash`。将它们只写入本地的 `TelegramSecrets.swift`，不要提交到公共仓库。

```swift
static let apiID: Int32 = 123456
static let apiHash = "你的 api_hash"
```

API ID/API Hash 不是 Telegram 账号密码；手机号、验证码和两步验证密码只能由用户在 App 内输入。

## 2. 准备 TDLib 二进制

TDLib 官方源码不会自动随这个示例工程提供预编译 iOS 二进制。需要在 macOS 上从官方 `tdlib/td` 源码构建适用于目标架构的 `TDLib.xcframework`，并将其加入 Xcode 工程。构建时应包含 `tdjson` C 接口，且公开以下函数：

- `td_json_client_create`
- `td_json_client_send`
- `td_json_client_receive`
- `td_json_client_execute`
- `td_json_client_destroy`

工程中的 `TDLibBridge.h` 是 Swift 到这些 C 函数的桥接声明。

## 3. 在 Xcode 开启真实实现

1. 将 `TDLib.xcframework` 拖入工程并勾选 App target。
2. 确认 `TDLibBridge.h` 已作为 Bridging Header：
   `SWIFT_OBJC_BRIDGING_HEADER = ProxyProfileDemo/TDLibBridge.h`
3. 在 App target 的 **Build Settings → Active Compilation Conditions** 中增加：
   `TD_LIB_ENABLED`
4. 填写 `TelegramSecrets.swift`。
5. 在真机或模拟器运行。

未开启 `TD_LIB_ENABLED` 时，界面会显示“等待配置 TDLib”，不会尝试登录 Telegram。

## 代理说明

- `TelegramClient` 使用 TDLib 官方 `addProxy` 接口。
- 支持 HTTP 和 SOCKS5；HTTPS 代理不能直接作为 TDLib 原生代理类型使用。
- 代理仅给这个独立客户端使用，不会影响官方 Telegram App 或其他 App。
- 不要把代理密码、Telegram 验证码或两步验证密码提交到代码仓库。

## 登录流程

TDLib 处理以下状态：

1. `authorizationStateWaitTdlibParameters`
2. `authorizationStateWaitEncryptionKey`
3. `authorizationStateWaitPhoneNumber`
4. `authorizationStateWaitCode`
5. `authorizationStateWaitPassword`（如果账号启用了两步验证）
6. `authorizationStateReady`

数据库加密密钥保存在 iOS Keychain，Telegram 登录凭据不写入 `UserDefaults`。

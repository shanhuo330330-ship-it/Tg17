import Foundation

struct SyntheticDeviceProfile: Codable, Identifiable, Equatable {
    let id: UUID
    let createdAt: Date
    let model: String
    let osVersion: String
    let chipFamily: String
    let memory: String
    let display: String
    let locale: String
    let timeZone: String
    let regionCode: String
    let localToken: String

    // MARK: - 客户端上报参数（真实注入 TDLib）

    /// TDLib setTdlibParameters 的 device_model
    var tdlibDeviceModel: String { model }

    /// TDLib setTdlibParameters 的 system_version
    var tdlibSystemVersion: String { osVersion }

    /// TDLib setTdlibParameters 的 system_language_code
    var tdlibLanguageCode: String {
        locale.replacingOccurrences(of: "_", with: "-")
    }

    static func makeRandom() -> SyntheticDeviceProfile {
        struct Preset {
            let model: String
            let os: String
            let chip: String
            let memory: String
            let display: String
        }

        let presets = [
            Preset(model: "iPhone 12", os: "iOS 16.7.10", chip: "A14 Bionic", memory: "4 GB", display: "6.1\" · 2532 × 1170"),
            Preset(model: "iPhone 13 Pro", os: "iOS 17.5.1", chip: "A15 Bionic", memory: "6 GB", display: "6.1\" · 2532 × 1170"),
            Preset(model: "iPhone 14 Pro Max", os: "iOS 17.6.1", chip: "A16 Bionic", memory: "6 GB", display: "6.7\" · 2796 × 1290"),
            Preset(model: "iPhone 15", os: "iOS 18.2", chip: "A16 Bionic", memory: "6 GB", display: "6.1\" · 2556 × 1179"),
            Preset(model: "iPhone 15 Pro Max", os: "iOS 18.3.2", chip: "A17 Pro", memory: "8 GB", display: "6.7\" · 2796 × 1290"),
            Preset(model: "iPhone 16 Pro", os: "iOS 18.4", chip: "A18 Pro", memory: "8 GB", display: "6.3\" · 2622 × 1206"),
            Preset(model: "iPhone 16e", os: "iOS 18.5", chip: "A18", memory: "8 GB", display: "6.1\" · 2532 × 1170")
        ]

        let localePairs = [
            ("zh_CN", "CN", "Asia/Shanghai"),
            ("en_US", "US", "America/New_York"),
            ("en_GB", "GB", "Europe/London"),
            ("ja_JP", "JP", "Asia/Tokyo"),
            ("ko_KR", "KR", "Asia/Seoul"),
            ("ru_RU", "RU", "Europe/Moscow")
        ]

        let preset = presets.randomElement() ?? presets[0]
        let pair = localePairs.randomElement() ?? localePairs[0]

        return SyntheticDeviceProfile(
            id: UUID(),
            createdAt: Date(),
            model: preset.model,
            osVersion: preset.os,
            chipFamily: preset.chip,
            memory: preset.memory,
            display: preset.display,
            locale: pair.0,
            timeZone: pair.2,
            regionCode: pair.1,
            localToken: Self.makeToken()
        )
    }

    private static func makeToken() -> String {
        UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(16).uppercased()
    }
}

enum ProxyScheme: String, Codable, CaseIterable, Identifiable {
    case http = "HTTP"
    case https = "HTTPS"
    case socks5 = "SOCKS5"

    var id: String { rawValue }
}

struct ProxyConfiguration: Codable, Equatable {
    var enabled = false
    var scheme: ProxyScheme = .http
    var host = ""
    var port = "8080"
    var username = ""
    var password = ""

    var isValid: Bool {
        guard !host.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              let portValue = UInt16(port), portValue > 0 else {
            return false
        }
        return true
    }

    var endpointText: String {
        let cleanHost = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanHost.isEmpty else { return "未配置" }
        return "\(scheme.rawValue) · \(cleanHost):\(port)"
    }
}

enum ProxyTestState {
    case idle
    case testing
    case success(ProxyTestResult)
    case failure(String)
}

struct ProxyTestResult {
    let egressIP: String?
    let latency: TimeInterval
}

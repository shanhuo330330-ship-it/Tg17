import Foundation
import Combine

#if TD_LIB_ENABLED
import UIKit
#endif

enum TelegramAuthState: Equatable {
    case unavailable(String)
    case idle
    case configuring
    case waitingPhone
    case waitingCode
    case waitingPassword
    case ready(String)
    case error(String)

    var title: String {
        switch self {
        case .unavailable: return "等待配置 TDLib"
        case .idle: return "未启动"
        case .configuring: return "正在初始化"
        case .waitingPhone: return "等待手机号"
        case .waitingCode: return "等待验证码"
        case .waitingPassword: return "等待两步验证密码"
        case .ready: return "已登录"
        case .error: return "需要处理错误"
        }
    }

    var systemImage: String {
        switch self {
        case .ready: return "checkmark.shield.fill"
        case .error: return "exclamationmark.triangle.fill"
        case .unavailable: return "wrench.and.screwdriver"
        case .waitingCode, .waitingPassword: return "lock"
        default: return "arrow.triangle.2.circlepath"
        }
    }
}

struct TelegramChat: Identifiable, Equatable {
    let id: Int64
    var title: String
    var unreadCount: Int

    var identity: Int64 { id }
}
#if TD_LIB_ENABLED

@MainActor
final class TelegramClient: ObservableObject {
    @Published private(set) var authState: TelegramAuthState = .idle
    @Published private(set) var userDisplayName: String?
    @Published private(set) var chats: [TelegramChat] = []

    private let databaseKeyAccount = "tdlib.database.encryption.key"
    private var client: UnsafeMutableRawPointer?
    private var receiveTask: Task<Void, Never>?
    private var pendingProxy: ProxyConfiguration?
    private var activeProfile: SyntheticDeviceProfile?
    private var configuredProxy: ProxyConfiguration?
    private var activeProxyID: Int64?
    private var hasConfiguredProxy = false

    deinit {
        receiveTask?.cancel()
        if let client {
            td_json_client_destroy(client)
        }
    }

    func start(proxy: ProxyConfiguration, profile: SyntheticDeviceProfile?) {
        guard TelegramSecrets.isConfigured else {
            authState = .unavailable("请先在 TelegramSecrets.swift 填写 API ID 和 API Hash。")
            return
        }

        pendingProxy = proxy

        // 设备身份变化时先优雅关闭当前会话（TDLib 正确的重启方式：
        // close 之后在同一实例上重新 setTdlibParameters，即可用新身份初始化）。
        // 会话数据保留在同一个加密数据库里，之后会自动恢复。
        if client != nil, activeProfile != profile {
            authState = .configuring
            hasConfiguredProxy = false
            activeProxyID = nil
            send(type: "close")
        }
        activeProfile = profile

        if client == nil {
            client = td_json_client_create()
        }
        guard let client else {
            authState = .error("无法创建 TDLib 客户端。")
            return
        }

        if receiveTask == nil {
            receiveTask = Task.detached(priority: .userInitiated) { [weak self, client] in
                while !Task.isCancelled {
                    guard let cString = td_json_client_receive(client, 1.0) else { continue }
                    let json = String(cString: cString)
                    await self?.handle(json: json)
                }
            }
        }

        authState = .configuring
        send(type: "getAuthorizationState")
    }

    func updateProxy(_ proxy: ProxyConfiguration) {
        if configuredProxy != Optional(proxy) {
            hasConfiguredProxy = false
        }
        pendingProxy = proxy
        guard client != nil else { return }

        if !proxy.enabled {
            send(type: "disableProxy")
            configuredProxy = nil
            hasConfiguredProxy = false
            return
        }

        guard !hasConfiguredProxy else { return }
        configureProxyIfNeeded()
    }

    func submitPhone(_ phone: String) {
        let value = phone.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            authState = .error("请输入包含国家区号的手机号，例如 +86…")
            return
        }

        send(
            type: "setAuthenticationPhoneNumber",
            parameters: [
                "phone_number": value,
                "settings": [
                    "@type": "phoneNumberAuthenticationSettings",
                    "allow_flash_call": false,
                    "allow_missed_call": false,
                    "is_current_phone_number": false,
                    "allow_sms_retriever_api": false
                ]
            ]
        )
    }

    func submitCode(_ code: String) {
        let value = code.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else {
            authState = .error("请输入 Telegram 验证码。")
            return
        }
        send(type: "checkAuthenticationCode", parameters: ["code": value])
    }

    func submitPassword(_ password: String) {
        guard !password.isEmpty else {
            authState = .error("请输入两步验证密码。")
            return
        }
        send(type: "checkAuthenticationPassword", parameters: ["password": password])
    }

    func logOut() {
        send(type: "logOut")
        userDisplayName = nil
        chats = []
        authState = .idle
    }

    private func send(type: String, parameters: [String: Any] = [:]) {
        guard let client else { return }
        var object = parameters
        object["@type"] = type
        guard JSONSerialization.isValidJSONObject(object),
              let data = try? JSONSerialization.data(withJSONObject: object),
              let json = String(data: data, encoding: .utf8) else {
            authState = .error("无法编码 TDLib 请求：\(type)")
            return
        }

        json.withCString { pointer in
            td_json_client_send(client, pointer)
        }
    }

    private func handle(json: String) {
        guard let data = json.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let type = object["@type"] as? String else {
            return
        }

        if type == "updateAuthorizationState",
           let state = object["authorization_state"] as? [String: Any],
           let stateType = state["@type"] as? String {
            handleAuthorizationState(stateType)
            return
        }

        if type == "updateUser", let user = object["user"] as? [String: Any] {
            updateUser(user)
            return
        }

        if type == "updateNewChat", let chat = object["chat"] as? [String: Any] {
            updateChat(chat)
            return
        }

        if type == "chat" {
            updateChat(object)
            return
        }

        if type == "chats", let chatIDs = object["chat_ids"] as? [Any] {
            for value in chatIDs {
                guard let number = value as? NSNumber else { continue }
                send(type: "getChat", parameters: ["chat_id": number.int64Value])
            }
            return
        }

        if type == "proxy", let id = object["id"] as? Int64 {
            activeProxyID = id
            configuredProxy = pendingProxy
            hasConfiguredProxy = true
            return
        }

        if type == "error" {
            let message = object["message"] as? String ?? "TDLib 返回未知错误。"
            let code = object["code"] as? Int ?? 0
            authState = .error("\(message)（\(code)）")
        }
    }

    private func handleAuthorizationState(_ type: String) {
        switch type {
        case "authorizationStateWaitTdlibParameters":
            sendTdlibParameters()
        case "authorizationStateWaitEncryptionKey":
            let key = databaseEncryptionKey()
            send(type: "setDatabaseEncryptionKey", parameters: ["key": key])
        case "authorizationStateWaitPhoneNumber":
            authState = .waitingPhone
            configureProxyIfNeeded()
        case "authorizationStateWaitCode":
            authState = .waitingCode
        case "authorizationStateWaitPassword":
            authState = .waitingPassword
        case "authorizationStateReady":
            configureProxyIfNeeded()
            authState = .ready(userDisplayName ?? "Telegram 用户")
            send(
                type: "getChats",
                parameters: [
                    "chat_list": ["@type": "chatListMain"],
                    "limit": 50
                ]
            )
        case "authorizationStateLoggingOut", "authorizationStateClosing":
            authState = .configuring
        case "authorizationStateClosed":
            // 身份切换或登出后的重新初始化入口
            sendTdlibParameters()
        default:
            break
        }
    }

    private func sendTdlibParameters() {
        let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        let language: String
        let systemVersion: String
        let model: String
        if let profile = activeProfile {
            // 注入合成设备参数：Telegram 侧看到的就是这里的值
            language = profile.tdlibLanguageCode
            systemVersion = profile.tdlibSystemVersion
            model = profile.tdlibDeviceModel
        } else {
            language = Locale.preferredLanguages.first?.split(separator: "-").first.map(String.init) ?? "en"
            systemVersion = "iOS \(UIDevice.current.systemVersion)"
            model = UIDevice.current.model
        }
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let directory = base.appendingPathComponent("tdlib", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        send(
            type: "setTdlibParameters",
            parameters: [
                "database_directory": directory.path,
                "files_directory": directory.appendingPathComponent("files", isDirectory: true).path,
                "use_file_database": true,
                "use_chat_info_database": true,
                "use_message_database": true,
                "use_secret_chats": true,
                "api_id": TelegramSecrets.apiID,
                "api_hash": TelegramSecrets.apiHash,
                "system_language_code": language,
                "device_model": model,
                "system_version": systemVersion,
                "application_version": appVersion,
                "enable_storage_optimizer": true,
                "ignore_file_names": false,
                "use_test_dc": false
            ]
        )
    }

    private func databaseEncryptionKey() -> String {
        if let existing = KeychainStore.data(for: databaseKeyAccount) {
            return existing.base64EncodedString()
        }

        let bytes = Data((0..<32).map { _ in UInt8.random(in: 0...255) })
        _ = KeychainStore.set(bytes, for: databaseKeyAccount)
        return bytes.base64EncodedString()
    }

    private func configureProxyIfNeeded() {
        guard let proxy = pendingProxy, proxy.enabled, !hasConfiguredProxy,
              let port = Int(proxy.port), port > 0 else { return }

        let type: [String: Any]
        switch proxy.scheme {
        case .http:
            type = [
                "@type": "proxyTypeHttp",
                "username": proxy.username,
                "password": proxy.password,
                "http_only": false
            ]
        case .socks5:
            type = [
                "@type": "proxyTypeSocks5",
                "username": proxy.username,
                "password": proxy.password
            ]
        case .https:
            authState = .error("TDLib 原生支持 HTTP、SOCKS5 和 MTProto 代理；HTTPS 代理需改为 HTTP 或 SOCKS5。")
            return
        }

        send(
            type: "addProxy",
            parameters: [
                "server_name": proxy.host,
                "port": port,
                "enable": true,
                "type": type
            ]
        )
    }

    private func updateUser(_ user: [String: Any]) {
        let first = user["first_name"] as? String ?? ""
        let last = user["last_name"] as? String ?? ""
        let username = user["username"] as? String ?? ""
        let name = [first, last].filter { !$0.isEmpty }.joined(separator: " ")
        userDisplayName = name.isEmpty ? (username.isEmpty ? nil : "@\(username)") : name
    }

    private func updateChat(_ chat: [String: Any]) {
        guard let number = chat["id"] as? NSNumber else { return }
        let id = number.int64Value
        let title = chat["title"] as? String ?? "未命名会话"
        let unreadCount = chat["unread_count"] as? Int ?? 0
        let value = TelegramChat(id: id, title: title, unreadCount: unreadCount)

        if let index = chats.firstIndex(where: { $0.id == id }) {
            chats[index] = value
        } else {
            chats.append(value)
        }
        chats.sort { lhs, rhs in
            if lhs.unreadCount != rhs.unreadCount {
                return lhs.unreadCount > rhs.unreadCount
            }
            return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
        }
    }
}

#else

@MainActor
final class TelegramClient: ObservableObject {
    @Published private(set) var authState: TelegramAuthState = .unavailable("当前工程还没有加入 TDLib.xcframework。")
    @Published private(set) var userDisplayName: String?
    @Published private(set) var chats: [TelegramChat] = []

    func start(proxy: ProxyConfiguration, profile: SyntheticDeviceProfile?) {
        authState = .unavailable("请加入 TDLib.xcframework，并在 Xcode 中开启 TD_LIB_ENABLED。")
    }

    func updateProxy(_ proxy: ProxyConfiguration) {}
    func submitPhone(_ phone: String) {}
    func submitCode(_ code: String) {}
    func submitPassword(_ password: String) {}
    func logOut() {}
}

#endif

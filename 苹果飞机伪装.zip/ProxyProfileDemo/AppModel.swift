import Foundation
import Combine

@MainActor
final class AppModel: ObservableObject {
    @Published private(set) var profile: SyntheticDeviceProfile
    @Published var useSyntheticProfile: Bool
    @Published var proxy: ProxyConfiguration
    @Published var proxyTestState: ProxyTestState = .idle

    private let profileKey = "synthetic.profile"
    private let profileAppliedKey = "synthetic.profile.applied"
    private let proxyKey = "proxy.configuration"

    init() {
        let defaults = UserDefaults.standard
        if let data = defaults.data(forKey: profileKey),
           let saved = try? JSONDecoder().decode(SyntheticDeviceProfile.self, from: data) {
            profile = saved
        } else {
            profile = .makeRandom()
        }

        useSyntheticProfile = defaults.object(forKey: profileAppliedKey) as? Bool ?? true

        if let data = defaults.data(forKey: proxyKey),
           let saved = try? JSONDecoder().decode(ProxyConfiguration.self, from: data) {
            proxy = saved
        } else {
            proxy = ProxyConfiguration()
        }

        persist()
    }

    /// 注入客户端时使用的设备身份：nil 表示使用真实设备参数
    var profileForClient: SyntheticDeviceProfile? {
        useSyntheticProfile ? profile : nil
    }

    func randomizeProfile() {
        profile = .makeRandom()
        persist()
    }

    func setUseSyntheticProfile(_ value: Bool) {
        useSyntheticProfile = value
        persist()
    }

    func saveProxy() {
        proxyTestState = .idle
        persist()
    }

    func testProxy() {
        guard proxy.enabled else {
            proxyTestState = .failure("请先打开“启用 App 内代理”。")
            return
        }

        guard proxy.isValid else {
            proxyTestState = .failure("请先填写有效的代理主机与端口。")
            return
        }

        let configuration = proxy
        proxyTestState = .testing

        Task {
            do {
                let result = try await ProxyTester.test(configuration)
                proxyTestState = .success(result)
            } catch {
                proxyTestState = .failure(error.localizedDescription)
            }
        }
    }

    private func persist() {
        UserDefaults.standard.set(useSyntheticProfile, forKey: profileAppliedKey)
        let encoder = JSONEncoder()
        if let profileData = try? encoder.encode(profile) {
            UserDefaults.standard.set(profileData, forKey: profileKey)
        }
        if let proxyData = try? encoder.encode(proxy) {
            UserDefaults.standard.set(proxyData, forKey: proxyKey)
        }
    }
}

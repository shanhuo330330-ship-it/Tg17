import Foundation
import Network

enum ProxyTester {
    private static let targetHost = "api.ipify.org"
    private static let targetPort: UInt16 = 80
    private static let requestPath = "/?format=json"

    static func test(_ configuration: ProxyConfiguration) async throws -> ProxyTestResult {
        guard configuration.isValid,
              let proxyPort = UInt16(configuration.port),
              let endpointPort = NWEndpoint.Port(rawValue: proxyPort) else {
            throw ProxyTestError.invalidConfiguration
        }

        let proxyHost = configuration.host.trimmingCharacters(in: .whitespacesAndNewlines)
        let parameters: NWParameters
        if configuration.scheme == .https {
            parameters = NWParameters(
                tls: NWProtocolTLS.Options(),
                tcp: NWProtocolTCP.Options()
            )
        } else {
            parameters = .tcp
        }

        let connection = NWConnection(
            host: NWEndpoint.Host(proxyHost),
            port: endpointPort,
            using: parameters
        )
        let start = Date()
        connection.start(queue: .global(qos: .userInitiated))
        defer { connection.cancel() }

        try await waitUntilReady(connection)

        switch configuration.scheme {
        case .http, .https:
            try await sendHTTPProxyRequest(connection, configuration: configuration)
        case .socks5:
            try await openSOCKS5Tunnel(connection, configuration: configuration)
            try await sendOriginRequest(connection)
        }

        let response = try await readHTTPResponse(connection)
        guard response.contains("200") else {
            throw ProxyTestError.badResponse
        }

        return ProxyTestResult(
            egressIP: extractIPv4(from: response),
            latency: Date().timeIntervalSince(start)
        )
    }

    private static func waitUntilReady(_ connection: NWConnection) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            var finished = false
            connection.stateUpdateHandler = { state in
                guard !finished else { return }
                switch state {
                case .ready:
                    finished = true
                    connection.stateUpdateHandler = nil
                    continuation.resume()
                case let .failed(error):
                    finished = true
                    connection.stateUpdateHandler = nil
                    continuation.resume(throwing: error)
                case .cancelled:
                    finished = true
                    connection.stateUpdateHandler = nil
                    continuation.resume(throwing: ProxyTestError.connectionCancelled)
                default:
                    break
                }
            }
        }
    }

    private static func sendHTTPProxyRequest(
        _ connection: NWConnection,
        configuration: ProxyConfiguration
    ) async throws {
        var request = "GET http://\(targetHost)\(requestPath) HTTP/1.1\r\n"
        request += "Host: \(targetHost)\r\n"
        request += "Accept: application/json\r\n"
        request += "Connection: close\r\n"
        request += "Proxy-Connection: close\r\n"

        if !configuration.username.isEmpty {
            let credential = "\(configuration.username):\(configuration.password)"
            let encoded = Data(credential.utf8).base64EncodedString()
            request += "Proxy-Authorization: Basic \(encoded)\r\n"
        }
        request += "\r\n"
        try await send(Data(request.utf8), over: connection)
    }

    private static func openSOCKS5Tunnel(
        _ connection: NWConnection,
        configuration: ProxyConfiguration
    ) async throws {
        var methods: [UInt8] = [0x00]
        if !configuration.username.isEmpty { methods.append(0x02) }
        var greeting = Data([0x05, UInt8(methods.count)])
        greeting.append(contentsOf: methods)
        try await send(greeting, over: connection)

        let methodReply = try await readExactly(2, from: connection)
        guard methodReply[0] == 0x05 else { throw ProxyTestError.invalidSOCKSReply }

        switch methodReply[1] {
        case 0x00:
            break
        case 0x02:
            let username = Array(configuration.username.utf8)
            let password = Array(configuration.password.utf8)
            guard username.count <= 255, password.count <= 255 else {
                throw ProxyTestError.credentialsTooLong
            }
            var auth = Data([0x01, UInt8(username.count)])
            auth.append(contentsOf: username)
            auth.append(UInt8(password.count))
            auth.append(contentsOf: password)
            try await send(auth, over: connection)
            let authReply = try await readExactly(2, from: connection)
            guard authReply[1] == 0x00 else { throw ProxyTestError.authenticationFailed }
        default:
            throw ProxyTestError.authenticationRequired
        }

        let host = Array(targetHost.utf8)
        guard host.count <= 255 else { throw ProxyTestError.invalidConfiguration }
        var request = Data([0x05, 0x01, 0x00, 0x03, UInt8(host.count)])
        request.append(contentsOf: host)
        request.append(UInt8(targetPort >> 8))
        request.append(UInt8(targetPort & 0xff))
        try await send(request, over: connection)

        let replyHead = try await readExactly(4, from: connection)
        guard replyHead[0] == 0x05, replyHead[1] == 0x00 else {
            throw ProxyTestError.socksConnectionRejected
        }

        switch replyHead[3] {
        case 0x01:
            _ = try await readExactly(4 + 2, from: connection)
        case 0x03:
            let lengthData = try await readExactly(1, from: connection)
            let length = lengthData[0]
            _ = try await readExactly(Int(length) + 2, from: connection)
        case 0x04:
            _ = try await readExactly(16 + 2, from: connection)
        default:
            throw ProxyTestError.invalidSOCKSReply
        }
    }

    private static func sendOriginRequest(_ connection: NWConnection) async throws {
        let request = "GET \(requestPath) HTTP/1.1\r\nHost: \(targetHost)\r\nAccept: application/json\r\nConnection: close\r\n\r\n"
        try await send(Data(request.utf8), over: connection)
    }

    private static func send(_ data: Data, over connection: NWConnection) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            connection.send(content: data, completion: .contentProcessed { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            })
        }
    }

    private static func readExactly(_ count: Int, from connection: NWConnection) async throws -> Data {
        var result = Data()
        while result.count < count {
            let chunk = try await receive(from: connection, maximumLength: count - result.count)
            if chunk.isEmpty { throw ProxyTestError.connectionClosed }
            result.append(chunk)
        }
        return result
    }

    private static func readHTTPResponse(_ connection: NWConnection) async throws -> String {
        var result = Data()
        let headerSeparator = Data("\r\n\r\n".utf8)

        for _ in 0..<16 {
            let chunk = try await receive(from: connection, maximumLength: 16 * 1024)
            if chunk.isEmpty { break }
            result.append(chunk)
            if result.range(of: headerSeparator) != nil,
               let text = String(data: result, encoding: .utf8),
               text.contains("\"ip\"") {
                break
            }
            if result.count >= 256 * 1024 { break }
        }

        guard let response = String(data: result, encoding: .utf8) else {
            throw ProxyTestError.badResponse
        }
        return response
    }

    private static func receive(from connection: NWConnection, maximumLength: Int) async throws -> Data {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Data, Error>) in
            connection.receive(minimumIncompleteLength: 1, maximumLength: max(1, maximumLength)) { data, _, isComplete, error in
                if let error {
                    continuation.resume(throwing: error)
                } else if let data, !data.isEmpty {
                    continuation.resume(returning: data)
                } else if isComplete {
                    continuation.resume(returning: Data())
                } else {
                    continuation.resume(returning: Data())
                }
            }
        }
    }

    private static func extractIPv4(from response: String) -> String? {
        guard let regex = try? NSRegularExpression(pattern: #"\b(?:\d{1,3}\.){3}\d{1,3}\b"#) else {
            return nil
        }
        let range = NSRange(response.startIndex..<response.endIndex, in: response)
        return regex.firstMatch(in: response, range: range).flatMap {
            Range($0.range, in: response).map { String(response[$0]) }
        }
    }
}

enum ProxyTestError: LocalizedError {
    case invalidConfiguration
    case connectionCancelled
    case connectionClosed
    case invalidSOCKSReply
    case authenticationRequired
    case authenticationFailed
    case credentialsTooLong
    case socksConnectionRejected
    case badResponse

    var errorDescription: String? {
        switch self {
        case .invalidConfiguration:
            return "代理配置无效，请检查主机和端口。"
        case .connectionCancelled:
            return "连接已取消。"
        case .connectionClosed:
            return "代理提前关闭了连接。"
        case .invalidSOCKSReply:
            return "收到无效的 SOCKS5 响应。"
        case .authenticationRequired:
            return "代理要求用户名和密码。"
        case .authenticationFailed:
            return "代理认证失败。"
        case .credentialsTooLong:
            return "代理用户名或密码过长。"
        case .socksConnectionRejected:
            return "SOCKS5 代理拒绝了目标连接。"
        case .badResponse:
            return "代理返回了无法识别的响应。"
        }
    }
}

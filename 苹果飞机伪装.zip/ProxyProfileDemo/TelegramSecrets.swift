import Foundation

/// 在自己的开发环境中填写从 my.telegram.org 获得的 API ID/API Hash。
/// 不要把真实账号密码、短信验证码或 2FA 密码写入这里。
enum TelegramSecrets {
    static let apiID: Int32 = 0
    static let apiHash = "PASTE_YOUR_API_HASH_HERE"

    static var isConfigured: Bool {
        apiID > 0 && !apiHash.isEmpty && apiHash != "PASTE_YOUR_API_HASH_HERE"
    }
}

import SwiftUI

struct TelegramView: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var client: TelegramClient

    @State private var phone = ""
    @State private var code = ""
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 12) {
                        Image(systemName: client.authState.systemImage)
                            .font(.title2)
                            .foregroundStyle(statusColor)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(client.authState.title)
                                .font(.headline)
                            if let name = client.userDisplayName {
                                Text(name)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                    }
                } header: {
                    Text("独立 Telegram 客户端")
                } footer: {
                    Text("本页面使用 TDLib 在本 App 内完成登录，不会打开或注入官方 Telegram App。")
                }

                loginSection
                chatsSection

                Section {
                    HStack {
                        Text("网络代理")
                        Spacer()
                        Text(model.proxy.enabled ? model.proxy.endpointText : "未启用")
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.trailing)
                    }
                    Text("代理只作用于这个 TDLib 客户端。HTTP/SOCKS5 支持取决于 TDLib 配置；HTTPS 代理不能直接作为 TDLib 原生代理。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } header: {
                    Text("连接方式")
                }

                if case .ready = client.authState {
                    Section {
                        Button(role: .destructive) {
                            client.logOut()
                        } label: {
                            Label("退出 Telegram 登录", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    }
                }
            }
            .navigationTitle("Telegram")
            .onAppear {
                client.start(proxy: model.proxy, profile: model.profileForClient)
            }
            .onChange(of: model.proxy) { _, newProxy in
                client.updateProxy(newProxy)
            }
            .onChange(of: model.profile) { _, _ in
                client.start(proxy: model.proxy, profile: model.profileForClient)
            }
            .onChange(of: model.useSyntheticProfile) { _, _ in
                client.start(proxy: model.proxy, profile: model.profileForClient)
            }
        }
    }

    @ViewBuilder
    private var loginSection: some View {
        switch client.authState {
        case .waitingPhone:
            Section {
                TextField("手机号（含国家区号）", text: $phone)
                    .keyboardType(.phonePad)
                Button("发送验证码") {
                    client.submitPhone(phone)
                }
                .disabled(phone.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            } header: {
                Text("手机号登录")
            } footer: {
                Text("验证码由 Telegram 官方服务发送。请不要把验证码提供给任何人。")
            }
        case .waitingCode:
            Section {
                TextField("Telegram 验证码", text: $code)
                    .keyboardType(.numberPad)
                Button("确认验证码") {
                    client.submitCode(code)
                }
                .disabled(code.isEmpty)
            } header: {
                Text("输入验证码")
            }
        case .waitingPassword:
            Section {
                SecureField("两步验证密码", text: $password)
                Button("确认密码") {
                    client.submitPassword(password)
                }
                .disabled(password.isEmpty)
            } header: {
                Text("两步验证")
            } footer: {
                Text("密码只提交给 TDLib/Telegram 流程，不应写入日志或分享给他人。")
            }
        case .unavailable, .error:
            Section {
                Text(statusMessage)
                    .foregroundStyle(.orange)
                if case .unavailable = client.authState {
                    Text("需要在自己的开发环境中加入 TDLib.xcframework，填写 TelegramSecrets.swift，并开启 TD_LIB_ENABLED。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            } header: {
                Text("配置提示")
            }
        default:
            EmptyView()
        }
    }

    @ViewBuilder
    private var chatsSection: some View {
        if case .ready = client.authState {
            Section {
                if client.chats.isEmpty {
                    Text("正在加载最近会话…")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(client.chats) { chat in
                        HStack {
                            Image(systemName: "person.2.fill")
                                .foregroundStyle(.indigo)
                            Text(chat.title)
                            Spacer()
                            if chat.unreadCount > 0 {
                                Text("\(chat.unreadCount)")
                                    .font(.caption.weight(.semibold).monospacedDigit())
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 7)
                                    .padding(.vertical, 3)
                                    .background(.indigo, in: Capsule())
                            }
                        }
                    }
                }
            } header: {
                Text("最近会话（只读预览）")
            } footer: {
                Text("当前示例只读取会话标题和未读数，还没有实现消息发送与媒体功能。")
            }
        }
    }

    private var statusMessage: String {
        switch client.authState {
        case let .unavailable(message), let .error(message):
            return message
        default:
            return ""
        }
    }

    private var statusColor: Color {
        switch client.authState {
        case .ready:
            return .green
        case .error, .unavailable:
            return .orange
        default:
            return .indigo
        }
    }
}

#Preview {
    TelegramView()
        .environmentObject(AppModel())
        .environmentObject(TelegramClient())
}

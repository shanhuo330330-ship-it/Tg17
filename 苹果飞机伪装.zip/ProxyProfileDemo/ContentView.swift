import SwiftUI

struct ContentView: View {
    @StateObject private var telegramClient = TelegramClient()

    var body: some View {
        TabView {
            TelegramView()
                .environmentObject(telegramClient)
                .tabItem {
                    Label("Telegram", systemImage: "paperplane")
                }

            ProfileView()
                .tabItem {
                    Label("QA 资料", systemImage: "iphone.gen3")
                }

            ProxyView()
                .tabItem {
                    Label("代理", systemImage: "network")
                }
        }
        .tint(.indigo)
    }
}

private struct ProfileView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    notice
                    profileCard
                    Toggle(isOn: Binding(
                        get: { model.useSyntheticProfile },
                        set: { model.setUseSyntheticProfile($0) }
                    )) {
                        Label("注入 Telegram 客户端（真实生效）", systemImage: "checkmark.seal")
                    }
                    .padding(12)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 14))

                    Button {
                        model.randomizeProfile()
                    } label: {
                        Label("重新生成设备资料", systemImage: "shuffle")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)

                    if model.useSyntheticProfile {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Telegram 侧将看到")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("device_model: \(model.profile.tdlibDeviceModel)")
                                .font(.caption.monospaced())
                            Text("system_version: \(model.profile.tdlibSystemVersion)")
                                .font(.caption.monospaced())
                            Text("language_code: \(model.profile.tdlibLanguageCode)")
                                .font(.caption.monospaced())
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.indigo.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                    }
                }
                .padding()
            }
            .navigationTitle("设备资料")
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Synthetic Device Lab")
                .font(.title2.weight(.bold))
            Text("App 进程内设备身份 — 注入后 Telegram 看到的设备参数即此资料")
                .foregroundStyle(.secondary)
        }
    }

    private var notice: some View {
        Label {
            Text("App 只能控制自己进程内上报的参数，无法修改系统 UDID、序列号、IMEI、MAC。开启注入后，本 App 的 Telegram 客户端会按此资料身份初始化。")
        } icon: {
            Image(systemName: "info.circle.fill")
        }
        .font(.footnote)
        .foregroundStyle(.blue)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.blue.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
    }

    private var profileCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Image(systemName: "iphone.gen3")
                    .font(.title2)
                    .foregroundStyle(.indigo)
                VStack(alignment: .leading, spacing: 3) {
                    Text(model.profile.model)
                        .font(.headline)
                    Text("Profile ID: \(model.profile.id.uuidString.prefix(8))…")
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
            .padding(.bottom, 12)

            Divider()

            Group {
                profileRow("系统版本", model.profile.osVersion, "gearshape")
                profileRow("芯片", model.profile.chipFamily, "cpu")
                profileRow("内存", model.profile.memory, "memorychip")
                profileRow("显示屏", model.profile.display, "rectangle.inset.filled")
                profileRow("语言区域", model.profile.locale, "character.book.closed")
                profileRow("时区", model.profile.timeZone, "clock")
                profileRow("地区码", model.profile.regionCode, "globe")
                profileRow("会话 Token", model.profile.localToken, "key")
            }
        }
        .padding()
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay {
            RoundedRectangle(cornerRadius: 18)
                .stroke(Color.secondary.opacity(0.15))
        }
    }

    private func profileRow(_ title: String, _ value: String, _ icon: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon)
                .frame(width: 22)
                .foregroundStyle(.secondary)
            Text(title)
                .foregroundStyle(.secondary)
                .frame(width: 92, alignment: .leading)
            Text(value)
                .font(.body.monospacedDigit())
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(.vertical, 8)
    }
}

private struct ProxyView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("启用 App 内代理", isOn: $model.proxy.enabled)
                    Picker("协议", selection: $model.proxy.scheme) {
                        ForEach(ProxyScheme.allCases) { scheme in
                            Text(scheme.rawValue).tag(scheme)
                        }
                    }
                    TextField("代理主机 / IP", text: $model.proxy.host)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    TextField("端口", text: $model.proxy.port)
                        .keyboardType(.numberPad)
                    TextField("用户名（可选）", text: $model.proxy.username)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    SecureField("密码（可选）", text: $model.proxy.password)
                } header: {
                    Text("代理配置")
                } footer: {
                    Text("配置保存在本机 App 沙盒内。启用后可供本 App 的 TDLib 独立客户端和出口测试使用，不会改变系统 Wi‑Fi/蜂窝网络，也不会影响官方 Telegram App 或其他 App。")
                }

                Section {
                    HStack {
                        Text("当前端点")
                        Spacer()
                        Text(model.proxy.endpointText)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.trailing)
                    }

                    Button {
                        model.saveProxy()
                    } label: {
                        Label("保存配置", systemImage: "checkmark.circle")
                    }
                    .disabled(!model.proxy.isValid)

                    Button {
                        model.testProxy()
                    } label: {
                        if case .testing = model.proxyTestState {
                            ProgressView()
                                .frame(maxWidth: .infinity)
                        } else {
                            Label("测试代理出口", systemImage: "antenna.radiowaves.left.and.right")
                        }
                    }
                    .disabled(!model.proxy.isValid || isTesting)
                } header: {
                    Text("连接测试")
                } footer: {
                    Text("测试会通过已填写的代理访问 api.ipify.org，并尝试显示代理出口 IP。独立 Telegram 客户端启用 TDLib 后，也会使用这里的 HTTP 或 SOCKS5 配置。请只使用你有权使用的代理。")
                }

                Section {
                    statusView
                } header: {
                    Text("状态")
                }
            }
            .navigationTitle("代理")
        }
    }

    private var isTesting: Bool {
        if case .testing = model.proxyTestState { return true }
        return false
    }

    @ViewBuilder
    private var statusView: some View {
        switch model.proxyTestState {
        case .idle:
            Text("尚未测试")
                .foregroundStyle(.secondary)
        case .testing:
            Label("正在通过代理连接…", systemImage: "arrow.triangle.2.circlepath")
        case let .success(result):
            VStack(alignment: .leading, spacing: 6) {
                Label("代理连接成功", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                if let ip = result.egressIP {
                    Text("代理出口 IP：\(ip)")
                        .font(.subheadline.monospaced())
                }
                Text(String(format: "延迟：%.0f ms", result.latency * 1000))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        case let .failure(message):
            Label(message, systemImage: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(AppModel())
}

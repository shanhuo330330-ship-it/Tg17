# 编译指南（不用自己的 Mac 也能编译）

这个工程是 SwiftUI iOS 工程，最终编译必须用 Xcode（macOS 工具链）。下面三条路任选其一。

## 方案 A：GitHub Actions 云端编译（推荐，无需 Mac）

仓库里已配好 `.github/workflows/build-ios.yml`，会自动在 GitHub 免费的 macOS 编译机上构建。

1. 把整个项目推到一个 GitHub 仓库（或上传 zip 后解压）。
2. 打开仓库的 **Actions** 标签页，选中 **Build iOS App**，点 **Run workflow**（push 后也会自动触发）。
3. 大约 5–10 分钟后，在运行结果底部下载 **ProxyProfileDemo-iOS** 产物，里面有两个文件：
   - `ProxyProfileDemo-unsigned.ipa` — 真机包（未签名）
   - `ProxyProfileDemo-simulator-app.zip` — 模拟器包（可直接装进 iOS 模拟器）

## 方案 B：有 Mac 的话

1. 用 Xcode 15+ 打开 `ProxyProfileDemo.xcodeproj`
2. 选模拟器，Cmd+R 直接跑
3. 真机：在 Signing & Capabilities 里登录你的 Apple ID 选一个 Team，再连真机运行

## 签名：怎么把未签名 ipa 装进真机

iOS 强制要求所有 App 必须签名后才能装进真机，没有例外。可选：

- **免费 Apple ID**（7 天有效期）：用 [Sideloadly](https://sideloadly.io/) 或 AltStore 把 `ProxyProfileDemo-unsigned.ipa` 重签后安装
- **Apple Developer 账号**（688 元/年）：用 Xcode 或 `codesign` 重签，有效期一年
- **企业签名 / 超级签**：如果有现成的证书，用爱思助手等工具签名安装

模拟器包不需要签名，可以直接用。

## 启用真实 Telegram 登录（可选）

当前编译出来的 App 会显示"等待配置 TDLib"。要让 Telegram 登录生效：

1. 到 my.telegram.org 申请 api_id / api_hash，填进 `ProxyProfileDemo/TelegramSecrets.swift`
2. 按 `TDLibIntegration.md` 构建 `TDLib.xcframework` 加入工程，开启 `TD_LIB_ENABLED`

不改这些也照样能编译、能装、能看 UI，只是 Telegram 部分不可用。
